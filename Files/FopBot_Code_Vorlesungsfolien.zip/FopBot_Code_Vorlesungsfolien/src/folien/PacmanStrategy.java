package folien;

public interface PacmanStrategy {
	int numberOfLeftTurns ();
}
