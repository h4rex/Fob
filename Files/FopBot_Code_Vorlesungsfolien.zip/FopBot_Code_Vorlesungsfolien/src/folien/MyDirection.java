package folien;

public enum MyDirection {
	UP,
    DOWN,
    LEFT,
    RIGHT
}
